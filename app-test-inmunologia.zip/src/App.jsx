import { useState } from 'react';

const preguntas = [
  {
    pregunta: "¿Cuál de los siguientes no forma parte del sistema inmunitario?",
    opciones: ["Moléculas", "Células", "Órganos", "Neuronas"],
    correcta: 3
  },
  {
    pregunta: "¿Qué tipo de célula madura en el timo?",
    opciones: ["Linfocito B", "Macrófago", "Linfocito T", "Célula NK"],
    correcta: 2
  },
  {
    pregunta: "¿Qué componente reconoce PAMPs?",
    opciones: ["BCR", "TCR", "PRR", "MHC"],
    correcta: 2
  }
];

export default function App() {
  const [indice, setIndice] = useState(0);
  const [seleccion, setSeleccion] = useState(null);
  const [aciertos, setAciertos] = useState(0);
  const [terminado, setTerminado] = useState(false);

  const preguntaActual = preguntas[indice];

  const handleRespuesta = (i) => {
    setSeleccion(i);
    if (i === preguntaActual.correcta) {
      setAciertos(aciertos + 1);
    }
    setTimeout(() => {
      if (indice + 1 < preguntas.length) {
        setIndice(indice + 1);
        setSeleccion(null);
      } else {
        setTerminado(true);
      }
    }, 800);
  };

  return (
    <main className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">Test de Inmunología</h1>
      {terminado ? (
        <div className="bg-white shadow-md rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-2">Resultado final</h2>
          <p>Has acertado {aciertos} de {preguntas.length} preguntas.</p>
          <button className="mt-4 px-4 py-2 bg-blue-500 text-white rounded" onClick={() => {
            setIndice(0);
            setAciertos(0);
            setSeleccion(null);
            setTerminado(false);
          }}>
            Volver a empezar
          </button>
        </div>
      ) : (
        <div className="bg-white shadow-md rounded-lg p-6 max-w-md w-full">
          <h2 className="text-lg font-semibold mb-4">{preguntaActual.pregunta}</h2>
          <div className="flex flex-col gap-2">
            {preguntaActual.opciones.map((opcion, i) => (
              <button
                key={i}
                className={\`px-4 py-2 rounded \${seleccion !== null ? (i === preguntaActual.correcta ? 'bg-green-500 text-white' : i === seleccion ? 'bg-red-500 text-white' : 'bg-gray-200') : 'bg-blue-200'}\`}
                disabled={seleccion !== null}
                onClick={() => handleRespuesta(i)}
              >
                {opcion}
              </button>
            ))}
          </div>
        </div>
      )}
    </main>
  );
}